# Investment Platform (Vercel‑Ready)

This is a **Next.js + Supabase + NOWPayments** investment platform, fully deployable on **Vercel**.

---
## 🚀 Quick Start

### 1️⃣ Supabase Setup
1. Create a new Supabase project.
2. Open the SQL Editor, paste contents of `supabase.sql`, and run it.
3. Default admin credentials:

```
Email: admin@example.com
Password: admin123
```

---
### 2️⃣ Environment Variables (in Vercel)

```
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
JWT_SECRET=your_long_secret
NOWPAYMENTS_API_KEY=your_nowpayments_api_key
NOWPAYMENTS_WEBHOOK_SECRET=your_webhook_secret
```

---
### 3️⃣ Local Development

```bash
npm install
npm run dev
```
Then open [http://localhost:3000](http://localhost:3000).

---
### 4️⃣ Deploying on Vercel

1. Go to [vercel.com](https://vercel.com) → **Import Project** → Upload this ZIP.
2. Framework Preset: **Next.js**
3. Root Directory: leave default (project root has `package.json`).
4. Build Command: `npm run build`
5. Output Directory: `.next`
6. Add the environment variables from above.
7. Click **Deploy**.

---
### 5️⃣ Crypto Payments (NOWPayments)

1. Get your API key from NOWPayments.
2. Set your webhook URL in NOWPayments:

```
https://<your-vercel-domain>/api/payments/webhook
```
3. Use the same secret as `NOWPAYMENTS_WEBHOOK_SECRET`.
4. After payment, transactions will be recorded in Supabase.

---
### ✅ Notes
- Uses Supabase for user + transaction data.
- Uses NOWPayments API for crypto payments.
- Fully compatible with Vercel serverless environment.
- Includes default admin account for login testing.

Enjoy your deployment 🚀
