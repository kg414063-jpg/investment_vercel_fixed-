-- Supabase schema and default admin

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  password_hash text not null,
  role text default 'user',
  created_at timestamp default now()
);

create table if not exists transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id),
  amount numeric,
  currency text,
  status text default 'pending',
  created_at timestamp default now()
);

-- Insert default admin user (bcrypt hash for "admin123")
insert into users (email, password_hash, role)
values ('admin@example.com', '$2a$10$Hj8I9J1XxV8jjzZ4F2ChkuRuVuU6hdwLMIKgE62MrPZ85wld4sTli', 'admin')
on conflict (email) do nothing;
