export default function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '5rem', fontFamily: 'Arial, sans-serif' }}>
      <h1>Welcome to the Investment Platform 🚀</h1>
      <p>Your Vercel deployment is successful.</p>
      <a href="/dashboard" style={{ color: '#0070f3', textDecoration: 'none', fontWeight: 'bold' }}>
        Go to Dashboard
      </a>
    </div>
  );
}
